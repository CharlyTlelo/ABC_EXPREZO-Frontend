import { Component } from '@angular/core';

@Component({
  selector: 'app-arquitectura',
  standalone: true,
  imports: [],
  templateUrl: './arquitectura.component.html',
  styleUrl: './arquitectura.component.scss'
})
export class ArquitecturaComponent {

}
