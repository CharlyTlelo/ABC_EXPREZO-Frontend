import { Component } from '@angular/core';

@Component({
  selector: 'app-aws',
  standalone: true,
  imports: [],
  templateUrl: './aws.component.html',
  styleUrl: './aws.component.scss'
})
export class AwsComponent {

}
