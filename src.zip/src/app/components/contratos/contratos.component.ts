import { Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import Swal from 'sweetalert2';
import { finalize } from 'rxjs/operators';
import { ContratosService, Contrato, Estado } from './services/contratos.service';

type TabKey = 'pendientes' | 'revision' | 'aprobados';

@Component({
  selector: 'app-contratos',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './contratos.component.html',
  styleUrls: ['./contratos.component.scss'],
})
export class ContratosComponent {
  private svc = inject(ContratosService);
  private router = inject(Router);

  activeTab = signal<TabKey>('pendientes');

  /** Fuente: signal del servicio */
  contratosAll = this.svc.items;

  /** Predicados */
  private isApproved = (c: Contrato) => c.estatus === 'APROBADO';
  private isRevision = (c: Contrato) => c.estatus === 'REVISION';
  private isPending  = (c: Contrato) => c.estatus === 'PENDIENTE';

  counts = computed(() => {
    const arr = this.contratosAll();
    return {
      pendientes: arr.filter(this.isPending).length,
      revision:   arr.filter(this.isRevision).length,
      aprobados:  arr.filter(this.isApproved).length,
    };
  });

  contratos = computed<Contrato[]>(() => {
    const arr = this.contratosAll();
    switch (this.activeTab()) {
      case 'aprobados': return arr.filter(this.isApproved);
      case 'revision':  return arr.filter(this.isRevision);
      default:          return arr.filter(this.isPending);
    }
  });

  setTab(tab: TabKey) { this.activeTab.set(tab); }

  // Navegación / acciones existentes
  irAgregar() { this.router.navigate(['/abc-exprezo/contratos/agregar']); }
  irModelado(folio: string) { this.router.navigate(['/abc-exprezo/contratos/modelado', folio]); }
  verDetalle(folio: string) { this.irModelado(folio); }

  async firmar(folio: string) {
    await Swal.fire('Validado', `Credenciales correctas para el folio ${folio}.`, 'success');
    this.router.navigate(['/abc-exprezo/contratos', 'requerimientos', folio]);
  }

  /** Acciones del revisor en tab "En revisión" */
  aprobar(folio: string) {
    Swal.fire({
      title: 'Aprobar requerimiento',
      text: `¿Confirmas aprobar el folio ${folio}?`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Sí, aprobar',
    }).then(res => {
      if (!res.isConfirmed) return;
      this.svc.updateStatus(folio, 'APROBADO')
        .pipe(finalize(() => {}))
        .subscribe({
          next: () => Swal.fire('Aprobado', 'El requerimiento fue aprobado.', 'success'),
          error: () => Swal.fire('Error', 'No se pudo aprobar. Intenta de nuevo.', 'error'),
        });
    });
  }

  rechazar(folio: string) {
    Swal.fire({
      title: 'Rechazar requerimiento',
      input: 'textarea',
      inputLabel: 'Motivo del rechazo (opcional)',
      inputPlaceholder: 'Describe qué falta o qué corregir…',
      showCancelButton: true,
      confirmButtonText: 'Rechazar',
      confirmButtonColor: '#d33',
    }).then(res => {
      if (!res.isConfirmed) return;
      this.svc.updateStatus(folio, 'PENDIENTE', res.value || '')
        .pipe(finalize(() => {}))
        .subscribe({
          next: () => Swal.fire('Rechazado', 'Se envió a Pendientes con tu comentario.', 'success'),
          error: () => Swal.fire('Error', 'No se pudo rechazar. Intenta de nuevo.', 'error'),
        });
    });
  }

  /** Carga inicial (llámalo desde ngOnInit si lo deseas) */
  ngOnInit() {
  this.svc.list().subscribe();
}
}
