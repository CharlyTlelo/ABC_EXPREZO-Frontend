import { Injectable, signal, WritableSignal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map, tap, catchError, of } from 'rxjs';

const API = '/api/contratos';

export type Estado = 'PENDIENTE' | 'REVISION' | 'APROBADO';

export interface Contrato {
  folio: string;
  contrato: string;
  descripcion: string;
  estatus: Estado | string;
}

@Injectable({ providedIn: 'root' })
export class ContratosService {
  constructor(private http: HttpClient) {}

  /** Fuente única de verdad en el front */
  items: WritableSignal<Contrato[]> = signal<Contrato[]>([]);

  /** Normaliza estados que puedan venir con tildes o minúsculas */
  private norm(s?: string): Estado {
    const t = (s ?? '').normalize('NFD').replace(/\p{Diacritic}/gu, '').toUpperCase().trim();
    if (t === 'APROBADO' || t === 'APROBADA') return 'APROBADO';
    if (t === 'EN REVISION' || t === 'REVISION') return 'REVISION';
    return 'PENDIENTE';
  }

  /** Helpers de manejo local */
  private upsertLocal(c: Contrato) {
    const u: Contrato = { ...c, estatus: this.norm(String(c.estatus)) };
    const curr = this.items();
    const idx = curr.findIndex(x => x.folio === u.folio);
    const next = curr.slice();
    if (idx >= 0) next[idx] = u; else next.unshift(u);
    this.items.set(next);
  }

  private removeLocal(folio: string) {
    this.items.set(this.items().filter(x => x.folio !== folio));
  }

  /** =======================
   *  Lectura / Listado
   * ======================= */
  list(): Observable<Contrato[]> {
    return this.http.get<Contrato[]>(API).pipe(
      map(arr => arr.map(c => ({ ...c, estatus: this.norm(String(c.estatus)) }))),
      tap(arr => this.items.set(arr))
    );
  }

  /** Obtiene 1 por folio: primero intenta desde memoria; si no está, consulta API */
  getByFolio(folio: string): Contrato | undefined {
    return this.items().find(x => x.folio === folio);
  }

  /** =======================
   *  Crear
   * ======================= */
  /** Crea en backend y refleja local; si tu comp no hace subscribe, aquí se hace */
  add(payload: Partial<Contrato>): void {
    // opcional: validar folio/contrato antes
    this.http.post<Contrato>(API, payload).pipe(
      map(c => ({ ...c, estatus: this.norm(String(c.estatus)) })),
      catchError(() => {
        // fallback si aún no tienes backend: inserta local
        if (payload.folio && payload.contrato) {
          this.upsertLocal(payload as Contrato);
        }
        return of(null);
      })
    ).subscribe(c => { if (c) this.upsertLocal(c); });
  }

  /** =======================
   *  Actualizar
   * ======================= */
  /** PATCH genérico por folio (para actualizar campos sueltos) */
  updateByFolio(folio: string, patch: Partial<Contrato>): void {
    this.http.patch<Contrato>(`${API}/${folio}`, patch).pipe(
      map(c => ({ ...c, estatus: this.norm(String(c.estatus)) })),
      catchError(() => {
        // fallback local si no hay backend
        const curr = this.getByFolio(folio);
        if (curr) this.upsertLocal({ ...curr, ...patch } as Contrato);
        return of(null);
      })
    ).subscribe(c => { if (c) this.upsertLocal(c); });
  }

  /** Actualiza SOLO el estado (flujo Pendientes/En revisión/Aprobados) */
  updateStatus(folio: string, status: Estado, comment?: string): Observable<void> {
    return this.http.patch<Contrato>(`${API}/${folio}/status`, { status, comment }).pipe(
      map(c => ({ ...c, estatus: this.norm(String(c.estatus)) })),
      tap(c => this.upsertLocal(c)),
      map(() => void 0),
      catchError(() => {
        // fallback local si no hay backend
        const curr = this.getByFolio(folio);
        if (curr) this.upsertLocal({ ...curr, estatus: status });
        return of(void 0);
      })
    );
  }

  /** =======================
   *  Eliminar
   * ======================= */
  removeByFolio(folio: string): void {
    this.http.delete<void>(`${API}/${folio}`).pipe(
      tap(() => this.removeLocal(folio)),
      catchError(() => {
        // fallback local
        this.removeLocal(folio);
        return of(void 0);
      })
    ).subscribe();
  }
}
