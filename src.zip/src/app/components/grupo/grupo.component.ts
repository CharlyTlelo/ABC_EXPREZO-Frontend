import { Component } from '@angular/core';

@Component({
  selector: 'app-grupo',
  standalone: true,
  imports: [],
  templateUrl: './grupo.component.html',
  styleUrl: './grupo.component.scss'
})
export class GrupoComponent {

}
