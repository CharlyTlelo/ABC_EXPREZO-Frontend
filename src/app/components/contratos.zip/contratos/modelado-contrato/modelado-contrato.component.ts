import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ContratosService } from '../services/contratos.service';

@Component({
  selector: 'app-modelado-contrato',
  standalone: true,
  imports: [CommonModule, RouterModule, ReactiveFormsModule],
  templateUrl: './modelado-contrato.component.html',
  styleUrls: ['./modelado-contrato.component.scss']
})
export class ModeladoContratoComponent {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private svc = inject(ContratosService);

  folio = this.route.snapshot.paramMap.get('folio') || '';

  form = this.fb.group({
    recoleccion: ['', Validators.required],
    conceptual:  ['', Validators.required],
    logico:      ['', Validators.required],
    fisico:      ['', Validators.required],
    validacion:  ['', Validators.required],
  });

  ngOnInit() {
    const contrato = this.svc.getByFolio(this.folio);
    const m = contrato?.modelado;
    if (m) this.form.patchValue(m);
  }

  guardar() {
    if (this.form.invalid) return;
    this.svc.updateByFolio(this.folio, { modelado: this.form.value as any });
    this.router.navigate(['/abc-exprezo/contratos']);
  }

  cancelar() {
    this.router.navigate(['/abc-exprezo/contratos']);
  }
}
